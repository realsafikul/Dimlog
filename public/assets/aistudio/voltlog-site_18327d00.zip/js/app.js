var KEY="power-report-v1";
var state={log:[],outAt:null};
var $=function(i){return document.getElementById(i)};
function load(){try{var s=localStorage.getItem(KEY);if(s){var p=JSON.parse(s);if(p&&p.log)state=p}}catch(e){}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch(e){}}
function fmt(ts){return new Date(ts).toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit",hour12:true})}
function fdate(ts){return new Date(ts).toLocaleDateString("en-GB",{weekday:"short",day:"numeric",month:"short",year:"numeric"})}
function toast(m){var t=$("toast");t.textContent=m;t.classList.add("show");clearTimeout(toast.h);toast.h=setTimeout(function(){t.classList.remove("show")},1800)}
function entryText(e){var o=e.type==="out";return (o?"Electricity out: ":"Electricity back: ")+fmt(e.ts)+"\nAutomatic Generator: "+(o?"ON":"OFF")}
function reportText(){return state.log.map(entryText).join("\n\n")}
function clock(){var n=Date.now();$("clock").textContent=fmt(n);$("date").textContent=new Date(n).toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}
function tick(){
  clock();
  if(state.outAt===null){$("timer").textContent="Power is normal";return}
  var m=Math.floor((Date.now()-state.outAt)/60000);
  $("timer").textContent="Outage running: "+(m>=60?Math.floor(m/60)+"h "+(m%60)+"m":m+" min");
}
function render(){
  var out=state.outAt!==null,b=$("main");
  b.className=out?"s-in":"s-out";
  b.innerHTML=out?'<span class="ic">💡</span><span class="lb">Electricity<br>Back</span>':'<span class="ic">🔌</span><span class="lb">Electricity<br>Out</span>';
  $("t1").textContent=out?"OUT":"ON";$("d1").className="dot"+(out?" red":"");
  $("t2").textContent=out?"ON":"OFF";$("d2").className="dot"+(out?" gen":" off");
  var el=$("report");
  if(!state.log.length){el.innerHTML='<div class="empty">Nothing yet.<br>Tap the big button when power goes out.</div>'}
  else{el.innerHTML=state.log.map(function(e,i){var o=e.type==="out";return '<div class="entry'+(o?'':' in')+'"><button class="cp" data-i="'+i+'" aria-label="Copy entry">📋</button><div class="en"><div class="dt">'+fdate(e.ts)+'</div><div>'+(o?"Electricity out: ":"Electricity back: ")+fmt(e.ts)+'</div><div>Automatic Generator: '+(o?"ON":"OFF")+'</div></div><button class="x" data-i="'+i+'" aria-label="Delete entry">✕</button></div>'}).join("");el.scrollTop=el.scrollHeight}
  $("count").textContent=state.log.length+(state.log.length===1?" entry":" entries");
  drawChart();
  tick();
}
function doCopy(txt,btn){
  if(!txt){toast("Nothing to copy yet");return}
  function ok(){toast("Copied ✓");if(btn){btn.textContent="✅";setTimeout(function(){btn.textContent="📋"},1200)}}
  function fallback(){var t=document.createElement("textarea");t.value=txt;t.style.position="fixed";t.style.opacity="0";document.body.appendChild(t);t.select();try{document.execCommand("copy");ok()}catch(e){toast("Could not copy")}document.body.removeChild(t)}
  try{navigator.clipboard.writeText(txt).then(ok,fallback)}catch(e){fallback()}
}
$("main").onclick=function(){
  var now=Date.now();
  if(state.outAt===null){state.log.push({type:"out",ts:now});state.outAt=now;toast("Electricity out saved · Generator ON")}
  else{state.log.push({type:"in",ts:now});state.outAt=null;toast("Electricity back saved · Generator OFF")}
  save();render();
};
$("copy").onclick=function(){doCopy(reportText())};
$("reset").onclick=function(){
  if(!state.log.length&&state.outAt===null)return;
  if(confirm("Clear the whole report?")){state={log:[],outAt:null};save();render();toast("Cleared")}
};
$("report").onclick=function(ev){
  var c=ev.target.closest(".cp");if(c){doCopy(entryText(state.log[+c.dataset.i]),c);return}
  var b=ev.target.closest(".x");if(!b)return;
  state.log.splice(+b.dataset.i,1);
  var l=state.log[state.log.length-1];state.outAt=(l&&l.type==="out")?l.ts:null;
  save();render();toast("Entry deleted");
};
function fm(m){m=Math.round(m);return m>=60?Math.floor(m/60)+"h "+(m%60)+"m":m+" min"}
function drawChart(){
  var box=$("tl"),W=Math.max(box.clientWidth,280),now=Date.now(),t0=now-864e5;
  var sm=W<520,pl=sm?44:58,pr=16,pt=14,hE=sm?130:160,gap=16,hG=sm?60:68,pb=30;
  var H=pt+hE+gap+hG+pb,iw=W-pl-pr,R=pl+iw;
  var x=function(t){return pl+(t-t0)/864e5*iw};
  var segs=[],st=null;
  state.log.forEach(function(q){if(q.type==="out")st=q.ts;else if(st!==null){segs.push({o:st,e:q.ts,live:0});st=null}});
  if(st!==null)segs.push({o:st,e:now,live:1});
  segs=segs.filter(function(g){return g.e>t0}).map(function(g){g.a=Math.max(g.o,t0);return g});
  var eOn=pt+36,eOff=pt+hE-14,eB=pt+hE,gy=eB+gap,gOn=gy+28,gOff=gy+hG-9,gB=gy+hG;
  var live=segs.length&&segs[segs.length-1].live;
  function pth(base,alt){var d="M"+pl+","+base;segs.forEach(function(g){var xa=x(g.a),xb=x(g.e);d+=" L"+xa+","+base+" L"+xa+","+alt+" L"+xb+","+alt;if(!g.live)d+=" L"+xb+","+base});return d+(live?"":" L"+R+","+base)}
  var tk=[],d=new Date(t0);d.setMinutes(0,0,0);d.setHours(d.getHours()+1);
  while(d.getTime()<=now){tk.push({x:x(d.getTime()),h:d.getHours()});d.setHours(d.getHours()+1)}
  var step=sm?6:3;
  function grid(y1,y2){return tk.map(function(k){return '<line class="gl'+(k.h%step===0?' mj':'')+'" x1="'+k.x+'" x2="'+k.x+'" y1="'+y1+'" y2="'+y2+'"/>'}).join("")}
  var s='<svg width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+'">';
  s+='<defs><linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--in);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--in);stop-opacity:0"/></linearGradient><linearGradient id="gg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:#f59e0b;stop-opacity:.7"/><stop offset="1" style="stop-color:#f59e0b;stop-opacity:.1"/></linearGradient><linearGradient id="gr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--out);stop-opacity:.3"/><stop offset="1" style="stop-color:var(--out);stop-opacity:.06"/></linearGradient>';
  s+='<clipPath id="ce"><rect x="'+pl+'" y="'+pt+'" width="'+iw+'" height="'+hE+'" rx="16"/></clipPath><clipPath id="cg"><rect x="'+pl+'" y="'+gy+'" width="'+iw+'" height="'+hG+'" rx="16"/></clipPath></defs>';
  s+='<rect class="pn" x="'+pl+'" y="'+pt+'" width="'+iw+'" height="'+hE+'" rx="16"/><rect class="pn" x="'+pl+'" y="'+gy+'" width="'+iw+'" height="'+hG+'" rx="16"/>';
  s+='<g clip-path="url(#ce)">'+grid(pt,eB);
  segs.forEach(function(g){var xa=x(g.a),xb=x(g.e);s+='<rect x="'+xa+'" y="'+pt+'" width="'+Math.max(xb-xa,3)+'" height="'+hE+'" fill="url(#gr)"/>'});
  s+='<path d="'+pth(eOn,eOff)+' L'+R+','+eB+' L'+pl+','+eB+' Z" fill="url(#ga)"/></g>';
  s+='<g clip-path="url(#cg)">'+grid(gy,gB);
  segs.forEach(function(g){var xa=x(g.a),xb=x(g.e);s+='<rect x="'+xa+'" y="'+gOn+'" width="'+Math.max(xb-xa,3)+'" height="'+(gB-gOn)+'" fill="url(#gg)"/>'});
  s+='</g>';
  s+='<path class="le" d="'+pth(eOn,eOff)+'"/>';
  s+='<path class="lm" d="'+pth(gOff,gOn)+'"/>';
  var tot=0,lng=0;
  segs.forEach(function(g){
    var xa=x(g.a),xb=x(g.e),m=(g.e-g.a)/60000;tot+=m;if(m>lng)lng=m;
    s+='<line class="lr" x1="'+xa+'" x2="'+xb+'" y1="'+eOff+'" y2="'+eOff+'"/><line class="la" x1="'+xa+'" x2="'+xb+'" y1="'+gOn+'" y2="'+gOn+'"/>';
    s+='<circle cx="'+xa+'" cy="'+eOff+'" r="5" fill="var(--out)" stroke="var(--card)" stroke-width="2"/>';
    if(!g.live)s+='<circle cx="'+xb+'" cy="'+eOn+'" r="5" fill="var(--in)" stroke="var(--card)" stroke-width="2"/>';
    if(xb-xa>46)s+='<text class="bt" x="'+((xa+xb)/2)+'" y="'+((eOn+eOff)/2+4)+'">'+fm(m)+'</text>';
    var txt="Out "+fmt(g.o)+(g.live?" \u2192 still out":" \u2192 Back "+fmt(g.e))+" ("+fm((g.e-g.o)/60000)+")";
    s+='<rect class="hit" data-t="'+txt+'" x="'+xa+'" y="'+pt+'" width="'+Math.max(xb-xa,12)+'" height="'+(gB-pt)+'"/>';
  });
  s+='<text class="cap" x="'+(pl+12)+'" y="'+(pt+17)+'">ELECTRICITY</text><text class="cap" x="'+(pl+12)+'" y="'+(gy+15)+'">GENERATOR</text>';
  s+='<text class="tx" x="'+(pl-8)+'" y="'+(eOn+4)+'" text-anchor="end" style="fill:var(--in)">ON</text><text class="tx" x="'+(pl-8)+'" y="'+(eOff+4)+'" text-anchor="end" style="fill:var(--out)">OUT</text>';
  s+='<text class="tx" x="'+(pl-8)+'" y="'+(gOn+4)+'" text-anchor="end" style="fill:#f59e0b">ON</text><text class="tx" x="'+(pl-8)+'" y="'+(gOff+4)+'" text-anchor="end">OFF</text>';
  tk.forEach(function(k){if(k.h%step===0&&k.x>pl+16&&k.x<R-34)s+='<text class="tx" x="'+k.x+'" y="'+(H-10)+'" text-anchor="middle">'+(k.h%12||12)+(k.h<12?" AM":" PM")+'</text>'});
  s+='<text class="tx" x="'+R+'" y="'+(H-10)+'" text-anchor="end" style="fill:var(--text);font-weight:800">Now</text>';
  var ny=live?eOff:eOn;
  s+='<line x1="'+R+'" x2="'+R+'" y1="'+pt+'" y2="'+gB+'" stroke="var(--text)" stroke-width="1.5" opacity=".5"/><circle class="ndr" cx="'+R+'" cy="'+ny+'" r="5"/><circle class="nd" cx="'+R+'" cy="'+ny+'" r="5"/></svg>';
  box.innerHTML=s;
  var pct=Math.max(0,Math.round((1440-tot)/1440*100));
  $("chips").innerHTML='<div class="chip"><small>Outages</small><b>'+segs.length+'</b></div><div class="chip"><small>Without power</small><b>'+(segs.length?fm(tot):"0 min")+'</b></div><div class="chip"><small>Longest</small><b>'+(segs.length?fm(lng):"\u2014")+'</b></div><div class="chip"><small>Power ON</small><b>'+pct+'%</b></div>';
}
$("tl").onclick=function(ev){var r=ev.target.closest(".hit");if(r)toast(r.dataset.t)};
window.addEventListener("resize",function(){clearTimeout(drawChart.h);drawChart.h=setTimeout(drawChart,120)});
load();render();setInterval(tick,1000);setInterval(drawChart,30000);

if("serviceWorker" in navigator&&location.protocol.indexOf("http")===0){window.addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){})})}

# ⚡ VoltLog

One-tap electricity outage reporter with generator status and a 24-hour power graph.
Built by **Safikul Islam**.

## Features
- Tap once for **Electricity out** (generator ON), tap again for **Electricity back** (generator OFF)
- Instant report in this format, ready to copy:

```
Electricity out: 03:30 PM
Automatic Generator: ON

Electricity back: 03:53 PM
Automatic Generator: OFF
```
- Copy a single entry or the whole report, delete any entry, clear all
- Live 24-hour graph for electricity and generator, with outage summary
- Works on phone, tablet and desktop, light and dark mode
- Installable and works offline (PWA). Data stays in your browser (localStorage)

## Project structure
```
voltlog/
├── index.html
├── css/style.css
├── js/app.js
├── favicon.svg
├── manifest.webmanifest
├── sw.js
├── netlify.toml
└── README.md
```

## Run locally
Open `index.html` in a browser, or serve the folder:
```
python3 -m http.server 8000
```

## Deploy to GitHub Pages
```
git init
git add .
git commit -m "VoltLog first version"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/voltlog.git
git push -u origin main
```
Then open the repo **Settings → Pages**, choose branch `main` and folder `/ (root)`, and save.
Your site will be at `https://YOUR-USERNAME.github.io/voltlog/`.

## Deploy to Netlify
- **Drag and drop:** open https://app.netlify.com/drop and drop the `voltlog` folder.
- **From GitHub:** Netlify → Add new site → Import from Git → pick the repo.
  Leave the build command empty and set the publish directory to `.`.
- Change the site name under Site configuration → Change site name.

## License
MIT
